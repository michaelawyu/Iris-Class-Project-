//
//  SecondViewController.swift
//  ReviewChangeWorld
//
//  Created by Ruoqi Wang on 5/4/16.
//  Copyright © 2016 Ruoqi Wang. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    //@IBOutlet weak var text1: UITextField!    
    
    @IBOutlet weak var Button1: UIButton!

    @IBOutlet weak var Button2: UIButton!
    
    @IBOutlet weak var Button3: UIButton!
    //mark action
    

    
   // @IBAction func Action1(sender: UIButton) {
    //}
    
    //@IBAction func Action2(sender: UIButton) {
   // }
    
   // @IBAction func Action3(sender: UIButton) {
   // }
    var section1 = ""
    var section2 = ""
    var section3 = ""
    var review1 = ""
    var review2 = ""
    var review3 = ""
    var review1_vote_for = 0
    var review1_vote_against = 0
    var review2_vote_for = 0
    var review2_vote_against = 0
    var review3_vote_for = 0
    var review3_vote_against = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.text1.text = "text1"
        self.Button1.setTitle(section1, forState:UIControlState.Normal)
        self.Button2.setTitle(section2, forState:UIControlState.Normal)
        self.Button3.setTitle(section3, forState:UIControlState.Normal)
        
        //self.Button3.setTitle("test3", forState:UIControlState.Normal)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        if (segue.identifier == "section1") {
            //get a reference to the destination view controller
            let destinationVC:ThirdViewController1 = segue.destinationViewController as! ThirdViewController1
            
            //set properties on the destination view controller
            destinationVC.section1 = section1
            destinationVC.review1 = review1
            destinationVC.review1_vote_for = review1_vote_for
            destinationVC.review1_vote_against = review1_vote_against
            
        }
        
        if (segue.identifier == "section2") {
            //get a reference to the destination view controller
            let destinationVC:ThirdViewController2 = segue.destinationViewController as! ThirdViewController2
            
            //set properties on the destination view controller
            destinationVC.section2 = section2
            destinationVC.review2 = review2
            destinationVC.review2_vote_for = review2_vote_for
            destinationVC.review2_vote_against = review2_vote_against
            
        }

        if (segue.identifier == "section3") {
            //get a reference to the destination view controller
            let destinationVC:ThirdViewController3 = segue.destinationViewController as! ThirdViewController3
            
            //set properties on the destination view controller
            destinationVC.section3 = section3
            destinationVC.review3 = review3
            destinationVC.review3_vote_for = review3_vote_for
            destinationVC.review3_vote_against = review3_vote_against
            
        }

    }

    
/*
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
*/
}
