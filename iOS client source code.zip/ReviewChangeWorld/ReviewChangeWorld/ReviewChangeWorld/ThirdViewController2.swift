//
//  ThirdViewController2.swift
//  ReviewChangeWorld
//
//  Created by Ruoqi Wang on 5/6/16.
//  Copyright © 2016 Ruoqi Wang. All rights reserved.
//

import UIKit

class ThirdViewController2: UIViewController {

    @IBOutlet weak var Label: UILabel!

    @IBOutlet weak var textField2: UITextField!
    
    @IBOutlet weak var for_num: UILabel!
    
    @IBOutlet weak var against_num: UILabel!
    
    var section2 = ""
    var review2 = ""
    var review2_vote_for = 0
    var review2_vote_against = 0
    
    @IBAction func Button_Votefor(sender: UIButton) {
        var countFor = String(1)
        // var countAgainst = String(1)
        //send http post request
        let scriptUrl = "http://api.randomuser.me/"
        let myUrl = NSURL(string: scriptUrl)
        //set http request
        let request = NSMutableURLRequest(URL:myUrl!)
        request.HTTPMethod = "post"
        
        let countString = NSString(format: "%@", countFor)
        let countData:NSData = countString.dataUsingEncoding(NSUTF8StringEncoding)!
        let base64CountString = countData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions())
        request.setValue(base64CountString, forHTTPHeaderField: "Authorization")
        
        
        // execute http request
        let postString = "countFor=" + countFor
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {
                //  check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? NSHTTPURLResponse where httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
        }
        task.resume()

        self.for_num.text = String(review2_vote_for+1)
    }
    
    @IBAction func Button_VoteAgainst(sender: UIButton) {
        var countAgainst = String(1)
        //send http post request
        let scriptUrl = "http://api.randomuser.me/"
        let myUrl = NSURL(string: scriptUrl)
        //set http request
        let request = NSMutableURLRequest(URL:myUrl!)
        request.HTTPMethod = "post"
        
        let countString = NSString(format: "%@", countAgainst)
        let countData:NSData = countString.dataUsingEncoding(NSUTF8StringEncoding)!
        let base64CountString = countData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions())
        request.setValue(base64CountString, forHTTPHeaderField: "Authorization")
        
        
        // execute http request
        let postString = "countAgainst=" + countAgainst
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {
                //  check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? NSHTTPURLResponse where httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
        }
        task.resume()

        self.against_num.text = String(review2_vote_against+1)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.Label.text = section2
        self.textField2.text = review2
        self.for_num.text = String(review2_vote_for)
        self.against_num.text = String(review2_vote_against)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
