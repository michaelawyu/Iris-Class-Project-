//
//  View3ViewController.swift
//  ReviewChangeWorld
//
//  Created by Ruoqi Wang on 5/3/16.
//  Copyright © 2016 Ruoqi Wang. All rights reserved.
//

import UIKit

class View3ViewController: UIViewController {

   
   // @IBOutlet weak var button1: UIButton!
   
   // @IBOutlet weak var button2: UIButton!
    
  //  @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var text1: UITextField!
    
    @IBOutlet weak var text2: UITextField!
    
    
    @IBOutlet weak var text3: UITextField!
    //mark action
    override func viewDidLoad() {
        super.viewDidLoad()
        self.text1.text = "text1"
        self.text2.text = "text2"
        self.text3.text = "text3"
        //self.button1.setTitle(<#T##title: String?##String?#>, forState: <#T##UIControlState#>) = "test"
        //self.button1.setTitle("test", forState:UIControlState.Normal)
        // Do any additional setup after loading the view.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
