//
//  ViewController.swift
//  ReviewChangeWorld
//
//  Created by Ruoqi Wang on 4/28/16.
//  Copyright © 2016 Ruoqi Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK: add properties
    

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    @IBOutlet weak var logInLabel: UILabel!

    
    //MARK: Actions
    
  
    @IBAction func try1(sender: UIButton) {
    }
    
    //@IBAction func button(sender: UIButton) {
   // }
    
    var status = ""
    var product = ""
    var section1 = "sectionhaha1"
    var section2 = "sectionhaha2"
    var section3 = "sectionhaha3"
    var review1 = "good idea1"
    var review2 = "good idea2"
    var review3 = "good idea3"
    var review1_vote_for = 0
    var review1_vote_against = 0
    var review2_vote_for = 0
    var review2_vote_against = 0
    var review3_vote_for = 0
    var review3_vote_against = 0
    
    
    
    @IBAction func submitLabelText(sender: UIButton) {
        print("hello")
        //get text from textfield
        let userName = nameTextField.text
        let password = passwordTextField.text
        
        //send http post request
        let scriptUrl = "http://reviewchangesworld.eastus.cloudapp.azure.com:5001/"
        let myUrl = NSURL(string: scriptUrl)
        //set http request
        let request = NSMutableURLRequest(URL:myUrl!)
        request.HTTPMethod = "post"
        
        let loginString = NSString(format: "%@:%@", userName!, password!)
        let loginData:NSData = loginString.dataUsingEncoding(NSUTF8StringEncoding)!
        let base64LoginString = loginData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions())
        request.setValue(base64LoginString, forHTTPHeaderField: "Authorization")
        
        
        // execute http request
//        
        let postString = "username="+userName!+"&"+"password="+password!
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {
               //  check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? NSHTTPURLResponse where httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
          //  let auth = ""
            self.status = (responseString?.componentsSeparatedByString(";")[0])!
            print (self.status)
            self.product = (responseString?.componentsSeparatedByString(";")[1])!
            self.section1 = (responseString?.componentsSeparatedByString(";")[2])!
            self.section2 = (responseString?.componentsSeparatedByString(";")[3])!
            self.section3 = (responseString?.componentsSeparatedByString(";")[4])!
            self.review1 = (responseString?.componentsSeparatedByString(";")[5])!
            self.review2 = (responseString?.componentsSeparatedByString(";")[6])!
            self.review3 = (responseString?.componentsSeparatedByString(";")[7])!
            self.review1_vote_for = Int( (responseString?.componentsSeparatedByString(";")[8])!)!
            self.review1_vote_against = Int( (responseString?.componentsSeparatedByString(";")[9])!)!
            self.review2_vote_for = Int( (responseString?.componentsSeparatedByString(";")[8])!)!
            self.review2_vote_against = Int( (responseString?.componentsSeparatedByString(";")[9])!)!
            self.review3_vote_for = Int( (responseString?.componentsSeparatedByString(";")[8])!)!
            self.review3_vote_against = Int( (responseString?.componentsSeparatedByString(";")[9])!)!
            
            //self.status = (responseString?.lowercaseString)!
            print(self.status)
        }
        task.resume()
      }
    

        
       // get data from server
//        request.HTTPMethod = "get"
//        
//        let task2 = NSURLSession.sharedSession().dataTaskWithRequest(request) {
//            data, response, error in
//            //check for error
//            if error != nil
//            {
//                print("error=\(error)")
//                return
//            }
//            //print out response string
//            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
//            print("responseString = \(responseString)")
//            
//            //convert server json response to NSDictionary
//            do {
//                if let convertedJsonIntoDict = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as? NSDictionary {
//                    
//                    // Print out dictionary
//                    print(convertedJsonIntoDict)
//                    
//                    // Get value by key
//                    let firstNameValue = convertedJsonIntoDict["username"] as? String
//                    //print(firstNameValue!)
//                    
//                }
//            } catch let error as NSError {
//                print(error.localizedDescription)
//            }
//            
//        }
//        
//        task2.resume()
//
//    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String!, sender: AnyObject!) -> Bool {
        if identifier == "loginSegue" { // you define it in the storyboard (click on the segue, then Attributes' inspector > Identifier
            
            var segueShouldOccur = true/** do whatever you need to set this var to true or false */
            if status == "ok" {
                segueShouldOccur = true
            }
            else{
                segueShouldOccur = false
            }
            
            
            if !segueShouldOccur {
                print("*** NOPE, segue wont occur")
                return false
            }
            else {
                print("*** YEP, segue will occur")
            }
        }
        
        // by default, transition
        return true
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        if (segue.identifier == "loginSegue") {
            //get a reference to the destination view controller
            let destinationVC:SecondViewController = segue.destinationViewController as! SecondViewController
            
            //set properties on the destination view controller
            destinationVC.section1 = section1
            destinationVC.section2 = section2
            destinationVC.section3 = section3
            destinationVC.review1 = review1
            destinationVC.review2 = review2
            destinationVC.review3 = review3
            destinationVC.review1_vote_for = review1_vote_for
            destinationVC.review1_vote_against = review1_vote_against
            destinationVC.review2_vote_for = review2_vote_for
            destinationVC.review2_vote_against = review2_vote_against
            destinationVC.review3_vote_for = review3_vote_for
            destinationVC.review3_vote_against = review3_vote_against            
           
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}

